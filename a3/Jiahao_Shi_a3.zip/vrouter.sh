#!/bin/bash

#Run script for vrouter distributed as part of
#Assignment 3
#Computer Networks (CS 456)
#Number of parameters: 3
#Parameter:
#    $1: <nfe_ip>
#    $2: <nfe_port>
#    $3: <virtual_router_id>

#For Python implementation
python3 vrouter.py $1 $2 $3